# Government School Supply Business Management App

Production-oriented Next.js + Supabase application for school visits, contacts, orders, inventory, deliveries, purchasing, payments, reminders, reports and CRM activity.

## Local setup

1. Install Node.js 20.
2. Copy `.env.example` to `.env.local`.
3. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
4. Run `npm install`.
5. Run `npm run qa`.
6. Run `npm run typecheck`.
7. Run `npm run build`.
8. Run `npm run dev`.

## Supabase

Apply migrations in `supabase/migrations` in timestamp order. Never expose a Supabase service-role key to the browser. Enable RLS for all business tables and keep Storage bucket `business-files` private.

## Production smoke test

After deployment, check `/api/health`. It must return HTTP 200 with `status: ok`. Then verify authentication, school CRUD, GPS permission, visit creation, order creation, payment creation, delivery completion, inventory changes and report loading with a real authenticated account.

## GitHub / Vercel

The repository intentionally contains no secrets. Configure Vercel environment variables and GitHub Actions secret `VERCEL_TOKEN` in the repository settings. The production workflow runs QA, TypeScript, Next.js build and then deploys a prebuilt artifact.
