import {redirect} from 'next/navigation'; export default function LegacyProducts(){redirect('/dashboard/products')}
