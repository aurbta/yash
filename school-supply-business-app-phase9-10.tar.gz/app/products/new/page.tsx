import {redirect} from 'next/navigation'; export default function LegacyNewProduct(){redirect('/dashboard/products/new')}
