import {redirect} from 'next/navigation'; export default function LegacyNewOrder(){redirect('/dashboard/orders/new')}
