import {redirect} from 'next/navigation'; export default function LegacyOrders(){redirect('/dashboard/orders')}
