import ProductsPage from '@/components/products/products-page'; export default ProductsPage;
