import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import { AppShell } from '@/components/app-shell';
import { FollowupsView } from '@/components/followups/followups-view';
export default async function FollowupsPage(){const sb=await createClient();const {data:{user}}=await sb.auth.getUser();if(!user)redirect('/login');const {data:p}=await sb.from('profiles').select('full_name').eq('id',user.id).maybeSingle();return <AppShell userName={p?.full_name||user.email||'User'}><FollowupsView/></AppShell>}
