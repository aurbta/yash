import { redirect } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { AppShell } from '@/components/app-shell';
import { CalendarDays, School, ShoppingCart, Truck, WalletCards, Bell, Package, BarChart3 } from 'lucide-react';

const money = (n:number) => `₹${Number(n||0).toLocaleString('en-IN',{maximumFractionDigits:0})}`;
const labels:Record<string,string> = {schools:'School',school_visits:'Visit',orders:'Order',deliveries:'Delivery',payments:'Payment',purchases:'Purchase',tasks:'Task',reminders:'Reminder'};

export default async function Dashboard(){
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user)redirect('/login');
 const [{data:profile},{data:summary},{data:activity}]=await Promise.all([
  supabase.from('profiles').select('full_name').eq('id',user.id).maybeSingle(),
  supabase.rpc('dashboard_summary'),
  supabase.rpc('recent_activity',{p_limit:12})
 ]);
 const s=(summary||{}) as any;
 const cards=[['SCHOOLS',String(s.schools_total||0),`${s.schools_active||0} active`,School],['TODAY’S VISITS',String(s.visits_today||0),'Visits recorded',CalendarDays],['TODAY’S ORDERS',String(s.orders_today||0),'Orders received',ShoppingCart],['PENDING ORDERS',String(s.orders_pending||0),'Need attention',Bell],['DELIVERIES TODAY',String(s.deliveries_today||0),'Scheduled / pending',Truck],['OUTSTANDING UDHAAR',money(s.outstanding),'Across all orders',WalletCards],['LOW STOCK',String(s.low_stock||0),'Products at minimum',Package],['30-DAY SALES',money(s.sales_30d),'Order value',BarChart3],['30-DAY COLLECTIONS',money(s.collections_30d),'Payments received',WalletCards]] as const;
 return <AppShell userName={profile?.full_name||user.email||'Owner'}><div className="space-y-6">
  <div><p className="text-sm text-gray-500">{new Intl.DateTimeFormat('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(new Date())}</p><h1 className="mt-1 text-2xl font-bold tracking-tight">Business dashboard</h1><p className="mt-1 text-sm text-gray-500">Live operational overview from your school supply database.</p></div>
  <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{cards.map(([label,value,sub,Icon])=><div key={label} className="rounded-2xl border bg-white p-5 shadow-sm"><div className="flex items-start justify-between"><div><p className="text-xs font-semibold tracking-wide text-gray-500">{label}</p><p className="mt-2 text-2xl font-bold">{value}</p><p className="mt-1 text-xs text-gray-500">{sub}</p></div><div className="rounded-xl bg-green-50 p-2.5 text-green-700"><Icon size={19}/></div></div></div>)}</div>
  <div className="grid gap-5 xl:grid-cols-3">
   <section className="rounded-2xl border bg-white p-5 shadow-sm xl:col-span-2"><div className="flex items-center justify-between"><div><h2 className="font-semibold">Recent activity</h2><p className="text-sm text-gray-500">Latest changes across your workspace.</p></div><Link href="/dashboard/reports" className="text-sm font-semibold text-green-700">Reports →</Link></div><div className="mt-4 divide-y">{(activity||[]).map((a:any)=><div key={a.id} className="flex items-center justify-between gap-4 py-3"><div><p className="text-sm font-medium">{labels[a.entity_type]||a.entity_type} <span className="text-gray-500">{a.action}</span></p><p className="text-xs text-gray-500">{a.actor_name} · {new Date(a.created_at).toLocaleString('en-IN')}</p></div><span className="text-xs text-gray-400">{String(a.entity_id).slice(0,8)}</span></div>)}{!activity?.length&&<p className="py-8 text-center text-sm text-gray-500">Activity will appear here as you work.</p>}</div></section>
   <section className="rounded-2xl border bg-white p-5 shadow-sm"><h2 className="font-semibold">Today’s follow-up</h2><div className="mt-4 space-y-3"><Metric label="Open follow-ups" value={s.followups_today||0} href="/dashboard/reminders"/><Metric label="Open tasks" value={s.tasks_today||0} href="/dashboard/tasks"/><Metric label="Low-stock products" value={s.low_stock||0} href="/dashboard/inventory"/></div><Link href="/dashboard/reports" className="mt-5 inline-flex w-full items-center justify-center rounded-xl bg-green-700 px-4 py-2.5 text-sm font-semibold text-white">Open reports</Link></section>
  </div>
 </div></AppShell>
}
function Metric({label,value,href}:{label:string;value:number;href:string}){return <Link href={href} className="flex items-center justify-between rounded-xl border p-3 hover:bg-gray-50"><span className="text-sm text-gray-600">{label}</span><span className="font-bold">{value}</span></Link>}
