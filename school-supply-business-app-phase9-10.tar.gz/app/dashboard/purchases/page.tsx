import Link from 'next/link';
import ReceiveButton from '@/components/purchases/receive-button';
import {SupplierPaymentForm} from '@/components/payments/supplier-payment-form';
import {AppShell} from '@/components/app-shell';
import {createClient} from '@/lib/supabase/server';
export default async function Purchases(){
 const s=await createClient(); const {data:{user}}=await s.auth.getUser(); if(!user)return null;
 const {data:p}=await s.from('profiles').select('full_name').eq('id',user.id).single();
 const {data:rows}=await s.from('purchases').select('id,purchase_number,purchase_date,status,total_amount,paid_amount,supplier_id,supplier:suppliers(name)').order('purchase_date',{ascending:false});
 return <AppShell userName={p?.full_name||'User'}><div className="space-y-6">
  <div className="flex items-center justify-between"><div><h1 className="text-2xl font-bold">Purchases</h1><p className="text-sm text-slate-500">Stock procurement from suppliers.</p></div><Link href="/dashboard/purchases/new" className="rounded-xl bg-green-700 px-4 py-2.5 text-sm font-semibold text-white">New Purchase</Link></div>
  <div className="space-y-3">{(rows||[]).map(x=>{const outstanding=Math.max(Number(x.total_amount)-Number(x.paid_amount||0),0);return <div key={x.id} className="rounded-2xl border bg-white p-4"><div className="flex justify-between gap-3"><div><b>Purchase #{x.purchase_number}</b><p className="text-sm text-slate-500">{(x.supplier as any)?.name||'Supplier'} · {new Date(x.purchase_date).toLocaleDateString('en-IN')}</p></div><div className="text-right"><b>₹{Number(x.total_amount).toLocaleString('en-IN')}</b><p className="text-xs text-slate-500">{x.status} · Paid ₹{Number(x.paid_amount||0).toLocaleString('en-IN')}</p>{x.status!=='RECEIVED'&&<ReceiveButton id={x.id}/>}</div></div>{outstanding>0&&x.supplier_id&&<SupplierPaymentForm supplierId={x.supplier_id} purchaseId={x.id} outstanding={outstanding}/>}</div>})}{!rows?.length&&<div className="rounded-2xl border border-dashed bg-white p-8 text-center text-slate-500">No purchases yet.</div>}</div>
 </div></AppShell>
}
