import {AppShell} from '@/components/app-shell';
import {createClient} from '@/lib/supabase/server';
import DeliveriesView from '@/components/deliveries/deliveries-view';
export default async function Deliveries(){const s=await createClient();const {data:{user}}=await s.auth.getUser();if(!user)return null;const {data:p}=await s.from('profiles').select('full_name').eq('id',user.id).single();return <AppShell userName={p?.full_name||'User'}><DeliveriesView/></AppShell>}
