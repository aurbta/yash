import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function GET(req: Request) {
  const url = new URL(req.url);
  const from = url.searchParams.get('from') || new Date(Date.now() - 29 * 86400000).toISOString().slice(0, 10);
  const to = url.searchParams.get('to') || new Date().toISOString().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to) || from > to) {
    return NextResponse.json({ error: 'Invalid date range' }, { status: 400 });
  }
  const end = new Date(`${to}T00:00:00Z`); end.setUTCDate(end.getUTCDate() + 1);
  const sb = await createClient();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { data, error } = await sb.from('orders').select('order_number,order_date,schools(name),status,payment_status,total_amount,paid_amount').gte('order_date', `${from}T00:00:00Z`).lt('order_date', end.toISOString()).order('order_date', { ascending: true });
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  const esc = (v: unknown) => `"${String(v ?? '').replaceAll('"','""')}"`;
  const lines = [['Order','Date','School','Status','Payment Status','Total','Paid','Outstanding'], ...(data || []).map((r: any) => [r.order_number, r.order_date, r.schools?.name, r.status, r.payment_status, r.total_amount, r.paid_amount, Math.max(Number(r.total_amount || 0)-Number(r.paid_amount || 0),0)])].map(row => row.map(esc).join(','));
  return new NextResponse(lines.join('\n'), { headers: { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="sales-${from}-to-${to}.csv"`, 'Cache-Control': 'private, no-store' } });
}
