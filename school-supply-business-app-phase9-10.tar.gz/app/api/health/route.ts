import { NextResponse } from 'next/server';
export const dynamic = 'force-dynamic';
export async function GET() {
  const ok = Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
  return NextResponse.json({ status: ok ? 'ok' : 'misconfigured', service: 'school-supply-business-app' }, { status: ok ? 200 : 503 });
}
