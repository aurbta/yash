'use client';

import { FormEvent, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function LoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const [error,setError]=useState(''); const [loading,setLoading]=useState(false);
  async function submit(e:FormEvent){e.preventDefault();setLoading(true);setError('');
    const {error}=await createClient().auth.signInWithPassword({email,password});
    if(error){setError(error.message);setLoading(false);return;}
    router.replace(params.get('next') || '/dashboard'); router.refresh();
  }
  return <main className="min-h-screen grid place-items-center p-5 bg-gradient-to-br from-green-50 via-white to-orange-50">
    <div className="w-full max-w-md rounded-3xl bg-white p-7 shadow-xl border border-gray-100">
      <div className="mb-8"><div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-green-700 text-white font-bold">SS</div><h1 className="mt-5 text-2xl font-bold">Welcome back</h1><p className="mt-1 text-sm text-gray-500">School Supply OS</p></div>
      <form onSubmit={submit} className="space-y-4">
        <label className="block text-sm font-medium">Email<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} className="mt-1.5 w-full rounded-xl border px-4 py-3 outline-none focus:ring-2 focus:ring-green-600" placeholder="you@example.com"/></label>
        <label className="block text-sm font-medium">Password<input required type="password" value={password} onChange={e=>setPassword(e.target.value)} className="mt-1.5 w-full rounded-xl border px-4 py-3 outline-none focus:ring-2 focus:ring-green-600" placeholder="••••••••"/></label>
        {error && <div className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}
        <button disabled={loading} className="w-full rounded-xl bg-green-700 py-3.5 font-semibold text-white disabled:opacity-60">{loading?'Signing in…':'Sign in'}</button>
      </form>
      <p className="mt-6 text-center text-sm text-gray-500">New business account? <a className="font-semibold text-green-700" href="/signup">Create one</a></p>
    </div>
  </main>
}
