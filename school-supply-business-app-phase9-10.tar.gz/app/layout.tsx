import type { Metadata } from "next";
import "./globals.css";
import { PwaRuntime } from "@/components/pwa-runtime";
export const metadata: Metadata={title:"School Supply OS",description:"Government school supply business management app",manifest:"/manifest.webmanifest"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}<PwaRuntime /></body></html>}
