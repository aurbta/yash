const CACHE='school-supply-os-v2';
const APP_SHELL=['/offline.html','/manifest.webmanifest','/icon-192.svg','/icon-512.svg'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(c=>c.addAll(APP_SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',event=>{
  const req=event.request;
  if(req.method!=='GET' || !req.url.startsWith(self.location.origin)) return;
  const url=new URL(req.url);
  if(url.pathname.startsWith('/dashboard') || url.pathname.startsWith('/orders') || url.pathname.startsWith('/api')) return;
  event.respondWith(fetch(req).then(res=>{if(res.ok){const copy=res.clone();caches.open(CACHE).then(c=>c.put(req,copy));}return res}).catch(()=>caches.match(req).then(cached=>cached||caches.match('/offline.html'))));
});
