import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'app/layout.tsx','app/dashboard/page.tsx','app/dashboard/schools/page.tsx',
  'app/dashboard/orders/page.tsx','app/dashboard/inventory/page.tsx',
  'app/dashboard/deliveries/page.tsx','app/dashboard/payments/page.tsx',
  'app/dashboard/reports/page.tsx','lib/supabase/client.ts','lib/supabase/server.ts',
  'supabase/migrations/20260929230000_phase_23_25_production_completion.sql',
  'public/manifest.webmanifest','public/sw.js','public/offline.html'
];
const failures=[];
for (const f of required) if(!fs.existsSync(path.join(root,f))) failures.push(`Missing required file: ${f}`);
const env = fs.readFileSync(path.join(root,'.env.example'),'utf8');
for (const k of ['NEXT_PUBLIC_SUPABASE_URL','NEXT_PUBLIC_SUPABASE_ANON_KEY']) if(!env.includes(k)) failures.push(`Missing env documentation: ${k}`);
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
for (const s of ['build','typecheck','qa']) if(!pkg.scripts?.[s]) failures.push(`Missing npm script: ${s}`);
const sourceFiles=[];
function walk(dir){ for(const e of fs.readdirSync(dir,{withFileTypes:true})){ if(['node_modules','.next','.git'].includes(e.name)) continue; const p=path.join(dir,e.name); if(e.isDirectory()) walk(p); else sourceFiles.push(p); }}
walk(root);
for(const p of sourceFiles){
  if(!/\.(ts|tsx|js|mjs|sql)$/.test(p)) continue;
  const s=fs.readFileSync(p,'utf8');
  if(/SUPABASE_SERVICE_ROLE_KEY\s*=\s*['\"][^'\"]+['\"]/.test(s)) failures.push(`Possible service-role secret in source: ${path.relative(root,p)}`);
}
if(failures.length){ console.error('QA STATIC CHECK: FAIL'); for(const f of failures) console.error('- '+f); process.exit(1); }
console.log('QA STATIC CHECK: PASS');
console.log(`Checked ${sourceFiles.length} project files and required production assets.`);
