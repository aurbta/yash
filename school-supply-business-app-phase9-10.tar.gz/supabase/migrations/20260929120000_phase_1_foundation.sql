create extension if not exists pgcrypto;

create type public.app_role as enum ('OWNER','ADMIN','SALES_PERSON','DELIVERY_PERSON','VIEWER');
create type public.school_status as enum ('ACTIVE','INACTIVE','ARCHIVED');
create type public.order_status as enum ('NEW','CONFIRMED','PREPARING','READY','OUT_FOR_DELIVERY','DELIVERED','PARTIALLY_DELIVERED','CANCELLED');
create type public.payment_status as enum ('UNPAID','PARTIAL','PAID','OVERDUE');
create type public.delivery_status as enum ('SCHEDULED','PREPARING','OUT_FOR_DELIVERY','DELIVERED','FAILED','RESCHEDULED');
create type public.priority_level as enum ('LOW','MEDIUM','HIGH','URGENT');

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  business_phone text,
  business_email text,
  address text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  organization_id uuid not null references public.organizations(id) on delete restrict,
  full_name text,
  role public.app_role not null default 'VIEWER',
  phone text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index profiles_org_idx on public.profiles(organization_id);

create table public.schools (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  udise_code text,
  address text,
  village_area text,
  district text,
  state text default 'Uttar Pradesh',
  latitude double precision,
  longitude double precision,
  school_type text,
  principal_name text,
  notes text,
  status public.school_status not null default 'ACTIVE',
  tags text[] not null default '{}',
  custom_fields jsonb not null default '{}',
  last_visit_at timestamptz,
  next_follow_up_at timestamptz,
  created_by uuid references public.profiles(id) on delete set null,
  updated_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index schools_org_udise_uidx on public.schools(organization_id, udise_code) where udise_code is not null and udise_code <> '';
create index schools_org_idx on public.schools(organization_id);
create index schools_name_idx on public.schools using gin (to_tsvector('simple', name));

create table public.school_contacts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  school_id uuid not null references public.schools(id) on delete cascade,
  name text not null,
  phone text not null,
  whatsapp_number text,
  role_title text,
  notes text,
  is_primary boolean not null default false,
  created_by uuid references public.profiles(id) on delete set null,
  updated_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index school_contacts_school_idx on public.school_contacts(school_id);
create index school_contacts_phone_idx on public.school_contacts(phone);

create table public.locations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  school_id uuid not null references public.schools(id) on delete cascade,
  latitude double precision not null,
  longitude double precision not null,
  accuracy_meters double precision,
  captured_at timestamptz not null default now(),
  is_current boolean not null default true,
  captured_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index locations_school_idx on public.locations(school_id, captured_at desc);

create table public.school_visits (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  school_id uuid not null references public.schools(id) on delete cascade,
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  latitude double precision,
  longitude double precision,
  person_met text,
  purpose text,
  order_received boolean not null default false,
  payment_collected boolean not null default false,
  follow_up_required boolean not null default false,
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index school_visits_school_idx on public.school_visits(school_id, started_at desc);
create index school_visits_org_date_idx on public.school_visits(organization_id, started_at desc);

create table public.product_categories (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now(),
  unique(organization_id, name)
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  category_id uuid references public.product_categories(id) on delete set null,
  name text not null,
  sku text,
  unit text not null default 'piece',
  purchase_price numeric(12,2) not null default 0,
  selling_price numeric(12,2) not null default 0,
  tax_percent numeric(5,2) not null default 0,
  current_stock numeric(14,3) not null default 0,
  minimum_stock numeric(14,3) not null default 0,
  supplier_id uuid,
  active boolean not null default true,
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  updated_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index products_org_sku_uidx on public.products(organization_id, sku) where sku is not null and sku <> '';
create index products_org_idx on public.products(organization_id);

create table public.product_templates (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  description text,
  active boolean not null default true,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(organization_id, name)
);

create table public.product_template_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  template_id uuid not null references public.product_templates(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete restrict,
  default_quantity numeric(14,3) not null default 1,
  sort_order integer not null default 0,
  unique(template_id, product_id)
);

create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  company text,
  phone text,
  whatsapp text,
  address text,
  notes text,
  outstanding_amount numeric(12,2) not null default 0,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.products add constraint products_supplier_fk foreign key (supplier_id) references public.suppliers(id) on delete set null;

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  order_number bigint generated always as identity,
  school_id uuid not null references public.schools(id) on delete restrict,
  contact_id uuid references public.school_contacts(id) on delete set null,
  order_date timestamptz not null default now(),
  expected_delivery_at timestamptz,
  status public.order_status not null default 'NEW',
  payment_status public.payment_status not null default 'UNPAID',
  subtotal numeric(14,2) not null default 0,
  discount numeric(14,2) not null default 0,
  tax_amount numeric(14,2) not null default 0,
  total_amount numeric(14,2) not null default 0,
  paid_amount numeric(14,2) not null default 0,
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  updated_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index orders_org_number_uidx on public.orders(organization_id, order_number);
create index orders_school_idx on public.orders(school_id, order_date desc);
create index orders_org_status_idx on public.orders(organization_id, status);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  custom_product_name text,
  quantity numeric(14,3) not null check (quantity > 0),
  unit text not null,
  unit_price numeric(12,2) not null default 0,
  discount numeric(12,2) not null default 0,
  tax_percent numeric(5,2) not null default 0,
  line_total numeric(14,2) not null default 0,
  notes text,
  created_at timestamptz not null default now(),
  check (product_id is not null or custom_product_name is not null)
);
create index order_items_order_idx on public.order_items(order_id);

create table public.deliveries (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  order_id uuid not null unique references public.orders(id) on delete cascade,
  school_id uuid not null references public.schools(id) on delete restrict,
  responsible_user_id uuid references public.profiles(id) on delete set null,
  scheduled_at timestamptz,
  delivered_at timestamptz,
  status public.delivery_status not null default 'SCHEDULED',
  proof_attachment_id uuid,
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.inventory (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  product_id uuid not null unique references public.products(id) on delete cascade,
  current_stock numeric(14,3) not null default 0,
  reserved_stock numeric(14,3) not null default 0,
  available_stock numeric(14,3) generated always as (current_stock - reserved_stock) stored,
  updated_at timestamptz not null default now()
);

create type public.inventory_transaction_type as enum ('PURCHASE','RESERVE','RELEASE','DELIVERY','ADJUSTMENT','RETURN');
create table public.inventory_transactions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete restrict,
  type public.inventory_transaction_type not null,
  quantity numeric(14,3) not null,
  reference_type text,
  reference_id uuid,
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index inventory_tx_product_idx on public.inventory_transactions(product_id, created_at desc);

create table public.purchases (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  supplier_id uuid not null references public.suppliers(id) on delete restrict,
  purchase_number bigint generated always as identity,
  purchase_date timestamptz not null default now(),
  expected_arrival_at timestamptz,
  status text not null default 'DRAFT',
  total_amount numeric(14,2) not null default 0,
  paid_amount numeric(14,2) not null default 0,
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.purchase_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  purchase_id uuid not null references public.purchases(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete restrict,
  quantity numeric(14,3) not null check(quantity > 0),
  unit text not null,
  unit_cost numeric(12,2) not null default 0,
  line_total numeric(14,2) not null default 0
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  school_id uuid not null references public.schools(id) on delete restrict,
  order_id uuid references public.orders(id) on delete set null,
  amount numeric(14,2) not null check(amount > 0),
  paid_at timestamptz not null default now(),
  payment_mode text not null,
  reference_number text,
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index payments_school_idx on public.payments(school_id, paid_at desc);

create table public.reminders (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  title text not null,
  description text,
  due_at timestamptz not null,
  school_id uuid references public.schools(id) on delete cascade,
  order_id uuid references public.orders(id) on delete cascade,
  priority public.priority_level not null default 'MEDIUM',
  repeat_rule text,
  completed_at timestamptz,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index reminders_due_idx on public.reminders(organization_id, due_at) where completed_at is null;

create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  title text not null,
  description text,
  due_at timestamptz,
  school_id uuid references public.schools(id) on delete cascade,
  order_id uuid references public.orders(id) on delete cascade,
  priority public.priority_level not null default 'MEDIUM',
  assigned_to uuid references public.profiles(id) on delete set null,
  completed_at timestamptz,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index tasks_due_idx on public.tasks(organization_id, due_at) where completed_at is null;

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text,
  type text not null default 'GENERAL',
  data jsonb not null default '{}',
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications(user_id, created_at desc);

create table public.attachments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  bucket text not null,
  storage_path text not null,
  file_name text not null,
  mime_type text,
  file_size bigint,
  school_id uuid references public.schools(id) on delete cascade,
  order_id uuid references public.orders(id) on delete cascade,
  visit_id uuid references public.school_visits(id) on delete cascade,
  payment_id uuid references public.payments(id) on delete cascade,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  entity_type text not null,
  entity_id uuid,
  action text not null,
  before_data jsonb,
  after_data jsonb,
  created_at timestamptz not null default now()
);
create index activity_logs_entity_idx on public.activity_logs(organization_id, entity_type, entity_id, created_at desc);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

create trigger organizations_updated_at before update on public.organizations for each row execute function public.set_updated_at();
create trigger profiles_updated_at before update on public.profiles for each row execute function public.set_updated_at();
create trigger schools_updated_at before update on public.schools for each row execute function public.set_updated_at();
create trigger school_contacts_updated_at before update on public.school_contacts for each row execute function public.set_updated_at();
create trigger products_updated_at before update on public.products for each row execute function public.set_updated_at();
create trigger product_templates_updated_at before update on public.product_templates for each row execute function public.set_updated_at();
create trigger suppliers_updated_at before update on public.suppliers for each row execute function public.set_updated_at();
create trigger orders_updated_at before update on public.orders for each row execute function public.set_updated_at();
create trigger deliveries_updated_at before update on public.deliveries for each row execute function public.set_updated_at();
create trigger inventory_updated_at before update on public.inventory for each row execute function public.set_updated_at();
create trigger purchases_updated_at before update on public.purchases for each row execute function public.set_updated_at();
create trigger reminders_updated_at before update on public.reminders for each row execute function public.set_updated_at();
create trigger tasks_updated_at before update on public.tasks for each row execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare org_id uuid;
begin
  insert into public.organizations(name) values ('My School Supply Business') returning id into org_id;
  insert into public.profiles(id, organization_id, full_name, role)
  values (new.id, org_id, coalesce(new.raw_user_meta_data->>'full_name', new.email), 'OWNER');
  return new;
end;
$$;
revoke all on function public.handle_new_user() from public;
grant execute on function public.handle_new_user() to supabase_auth_admin;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

alter table public.organizations enable row level security;
alter table public.profiles enable row level security;
alter table public.schools enable row level security;
alter table public.school_contacts enable row level security;
alter table public.locations enable row level security;
alter table public.school_visits enable row level security;
alter table public.product_categories enable row level security;
alter table public.products enable row level security;
alter table public.product_templates enable row level security;
alter table public.product_template_items enable row level security;
alter table public.suppliers enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.deliveries enable row level security;
alter table public.inventory enable row level security;
alter table public.inventory_transactions enable row level security;
alter table public.purchases enable row level security;
alter table public.purchase_items enable row level security;
alter table public.payments enable row level security;
alter table public.reminders enable row level security;
alter table public.tasks enable row level security;
alter table public.notifications enable row level security;
alter table public.attachments enable row level security;
alter table public.activity_logs enable row level security;

create policy "profile self read" on public.profiles for select to authenticated using (id = (select auth.uid()));
create policy "profile self update" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));
create policy "organization member read" on public.organizations for select to authenticated using (id = (select p.organization_id from public.profiles p where p.id = (select auth.uid())));

create or replace function public.current_user_org_id()
returns uuid language sql stable
as $$ select organization_id from public.profiles where id = (select auth.uid()) $$;

revoke all on function public.current_user_org_id() from public;
grant execute on function public.current_user_org_id() to authenticated;

-- Organization-scoped CRUD policies.
create policy "org crud" on public.schools for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.school_contacts for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.locations for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.school_visits for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.product_categories for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.products for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.product_templates for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.product_template_items for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.suppliers for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.orders for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.order_items for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.deliveries for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.inventory for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.inventory_transactions for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.purchases for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.purchase_items for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.payments for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.reminders for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.tasks for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.notifications for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.attachments for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));
create policy "org crud" on public.activity_logs for all to authenticated using (organization_id = (select public.current_user_org_id())) with check (organization_id = (select public.current_user_org_id()));

insert into storage.buckets (id, name, public) values ('business-files','business-files',false) on conflict (id) do nothing;
