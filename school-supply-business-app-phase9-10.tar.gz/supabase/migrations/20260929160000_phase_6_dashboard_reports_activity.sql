-- Phase 6: dashboard aggregates, reporting functions and automatic activity timeline.
create index if not exists schools_org_status_idx on public.schools(organization_id,status);
create index if not exists visits_org_started_idx on public.school_visits(organization_id,started_at desc);
create index if not exists orders_org_date_idx on public.orders(organization_id,order_date desc);
create index if not exists orders_org_status_idx on public.orders(organization_id,status);
create index if not exists deliveries_org_schedule_idx on public.deliveries(organization_id,scheduled_at);
create index if not exists inventory_org_stock_idx on public.inventory(organization_id,current_stock);
create index if not exists activity_logs_org_created_idx on public.activity_logs(organization_id,created_at desc);

create or replace function public.log_activity() returns trigger language plpgsql security invoker set search_path=public as $$
declare v_org uuid; v_entity uuid; v_after jsonb; v_before jsonb;
begin
 v_org:=coalesce((to_jsonb(new)->>'organization_id')::uuid,(to_jsonb(old)->>'organization_id')::uuid); v_entity:=coalesce(new.id,old.id);
 if v_org is null or v_entity is null then return coalesce(new,old); end if;
 if tg_op='INSERT' then v_after:=to_jsonb(new); elsif tg_op='UPDATE' then v_before:=to_jsonb(old); v_after:=to_jsonb(new); else v_before:=to_jsonb(old); end if;
 insert into public.activity_logs(organization_id,actor_id,entity_type,entity_id,action,before_data,after_data) values(v_org,auth.uid(),tg_table_name,v_entity,lower(tg_op),v_before,v_after);
 return coalesce(new,old);
end; $$;

drop trigger if exists schools_activity_log on public.schools; create trigger schools_activity_log after insert or update or delete on public.schools for each row execute function public.log_activity();
drop trigger if exists visits_activity_log on public.school_visits; create trigger visits_activity_log after insert or update or delete on public.school_visits for each row execute function public.log_activity();
drop trigger if exists orders_activity_log on public.orders; create trigger orders_activity_log after insert or update or delete on public.orders for each row execute function public.log_activity();
drop trigger if exists deliveries_activity_log on public.deliveries; create trigger deliveries_activity_log after insert or update or delete on public.deliveries for each row execute function public.log_activity();
drop trigger if exists payments_activity_log on public.payments; create trigger payments_activity_log after insert or update or delete on public.payments for each row execute function public.log_activity();
drop trigger if exists purchases_activity_log on public.purchases; create trigger purchases_activity_log after insert or update or delete on public.purchases for each row execute function public.log_activity();
drop trigger if exists tasks_activity_log on public.tasks; create trigger tasks_activity_log after insert or update or delete on public.tasks for each row execute function public.log_activity();
drop trigger if exists reminders_activity_log on public.reminders; create trigger reminders_activity_log after insert or update or delete on public.reminders for each row execute function public.log_activity();

create or replace function public.dashboard_summary() returns jsonb language plpgsql security invoker set search_path=public as $$
declare v_org uuid:=public.current_user_org_id(); v_today date:=current_date; result jsonb;
begin
 if v_org is null then raise exception 'No organization found'; end if;
 select jsonb_build_object('schools_total',(select count(*) from public.schools where organization_id=v_org),'schools_active',(select count(*) from public.schools where organization_id=v_org and status='ACTIVE'),'visits_today',(select count(*) from public.school_visits where organization_id=v_org and started_at::date=v_today),'orders_today',(select count(*) from public.orders where organization_id=v_org and order_date::date=v_today),'orders_pending',(select count(*) from public.orders where organization_id=v_org and status in ('NEW','CONFIRMED','PREPARING','READY','OUT_FOR_DELIVERY','PARTIALLY_DELIVERED')),'deliveries_today',(select count(*) from public.deliveries where organization_id=v_org and scheduled_at::date=v_today and status<>'DELIVERED'),'outstanding',coalesce((select sum(greatest(total_amount-paid_amount,0)) from public.orders where organization_id=v_org and total_amount>paid_amount),0),'low_stock',(select count(*) from public.products where organization_id=v_org and active=true and current_stock<=minimum_stock),'sales_30d',coalesce((select sum(total_amount) from public.orders where organization_id=v_org and order_date>=now()-interval '30 days'),0),'collections_30d',coalesce((select sum(amount) from public.payments where organization_id=v_org and paid_at>=now()-interval '30 days'),0),'followups_today',(select count(*) from public.reminders where organization_id=v_org and completed_at is null and due_at::date<=v_today),'tasks_today',(select count(*) from public.tasks where organization_id=v_org and completed_at is null and due_at::date<=v_today)) into result;
 return result;
end; $$;

create or replace function public.report_summary(p_from timestamptz,p_to timestamptz) returns jsonb language plpgsql security invoker set search_path=public as $$
declare v_org uuid:=public.current_user_org_id();
begin
 if v_org is null then raise exception 'No organization found'; end if;
 return jsonb_build_object('sales',coalesce((select sum(total_amount) from public.orders where organization_id=v_org and order_date>=p_from and order_date<p_to),0),'collections',coalesce((select sum(amount) from public.payments where organization_id=v_org and paid_at>=p_from and paid_at<p_to),0),'orders',(select count(*) from public.orders where organization_id=v_org and order_date>=p_from and order_date<p_to),'visits',(select count(*) from public.school_visits where organization_id=v_org and started_at>=p_from and started_at<p_to),'deliveries',(select count(*) from public.deliveries where organization_id=v_org and created_at>=p_from and created_at<p_to),'outstanding',coalesce((select sum(greatest(total_amount-paid_amount,0)) from public.orders where organization_id=v_org and total_amount>paid_amount),0),'low_stock',(select count(*) from public.products where organization_id=v_org and active=true and current_stock<=minimum_stock));
end; $$;

create or replace function public.sales_report(p_from timestamptz,p_to timestamptz) returns table(report_date date,order_count bigint,sales numeric,collections numeric) language sql security invoker set search_path=public as $$
with dates as(select generate_series(p_from::date,(p_to-interval '1 second')::date,interval '1 day')::date as report_date),o as(select order_date::date report_date,count(*) order_count,coalesce(sum(total_amount),0) sales from public.orders where organization_id=public.current_user_org_id() and order_date>=p_from and order_date<p_to group by 1),p as(select paid_at::date report_date,coalesce(sum(amount),0) collections from public.payments where organization_id=public.current_user_org_id() and paid_at>=p_from and paid_at<p_to group by 1) select d.report_date,coalesce(o.order_count,0),coalesce(o.sales,0),coalesce(p.collections,0) from dates d left join o using(report_date) left join p using(report_date) order by d.report_date desc; $$;

grant execute on function public.dashboard_summary() to authenticated;
grant execute on function public.report_summary(timestamptz,timestamptz) to authenticated;
grant execute on function public.sales_report(timestamptz,timestamptz) to authenticated;
revoke execute on function public.dashboard_summary() from anon;
revoke execute on function public.report_summary(timestamptz,timestamptz) from anon;
revoke execute on function public.sales_report(timestamptz,timestamptz) from anon;
