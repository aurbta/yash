-- Phase 17-19: reporting helpers, role-aware RPCs, atomic order creation.
create or replace function public.current_user_role()
returns public.app_role language sql stable security invoker set search_path=public as $$
  select role from public.profiles where id=(select auth.uid()) limit 1;
$$;
grant execute on function public.current_user_role() to authenticated;
revoke execute on function public.current_user_role() from anon,public;

create or replace function public.create_order_atomic(
 p_school_id uuid,
 p_contact_id uuid,
 p_expected_delivery_at timestamptz,
 p_notes text,
 p_items jsonb
) returns uuid language plpgsql security invoker set search_path=public as $$
declare
 v_org uuid:=public.current_user_org_id(); v_order uuid; v_subtotal numeric:=0; r record; v_school uuid;
begin
 if v_org is null then raise exception 'Organization not found'; end if;
 select id into v_school from public.schools where id=p_school_id and organization_id=v_org and status='ACTIVE';
 if v_school is null then raise exception 'School not found or inactive'; end if;
 if p_contact_id is not null and not exists(select 1 from public.school_contacts where id=p_contact_id and school_id=p_school_id and organization_id=v_org) then raise exception 'Invalid school contact'; end if;
 if jsonb_array_length(coalesce(p_items,'[]'::jsonb))=0 then raise exception 'Order must contain at least one item'; end if;
 for r in select * from jsonb_to_recordset(p_items) as x(product_id uuid,custom_product_name text,quantity numeric,unit text,unit_price numeric,discount numeric,tax_percent numeric) loop
   if r.quantity is null or r.quantity<=0 or r.unit_price is null or r.unit_price<0 then raise exception 'Invalid order item'; end if;
   if r.product_id is null and nullif(trim(r.custom_product_name),'') is null then raise exception 'Product or custom item name required'; end if;
   if r.product_id is not null and not exists(select 1 from public.products where id=r.product_id and organization_id=v_org and active=true) then raise exception 'Invalid product'; end if;
   v_subtotal:=v_subtotal+(r.quantity*r.unit_price)-coalesce(r.discount,0);
 end loop;
 if v_subtotal<=0 then raise exception 'Order total must be greater than zero'; end if;
 insert into public.orders(organization_id,school_id,contact_id,expected_delivery_at,notes,subtotal,total_amount,created_by,updated_by)
 values(v_org,p_school_id,p_contact_id,p_expected_delivery_at,p_notes,v_subtotal,v_subtotal,auth.uid(),auth.uid()) returning id into v_order;
 for r in select * from jsonb_to_recordset(p_items) as x(product_id uuid,custom_product_name text,quantity numeric,unit text,unit_price numeric,discount numeric,tax_percent numeric) loop
   insert into public.order_items(organization_id,order_id,product_id,custom_product_name,quantity,unit,unit_price,discount,tax_percent,line_total,notes)
   values(v_org,v_order,r.product_id,nullif(trim(r.custom_product_name),''),r.quantity,coalesce(nullif(r.unit,''),'piece'),r.unit_price,coalesce(r.discount,0),coalesce(r.tax_percent,0),(r.quantity*r.unit_price)-coalesce(r.discount,0),null);
 end loop;
 return v_order;
end; $$;
grant execute on function public.create_order_atomic(uuid,uuid,timestamptz,text,jsonb) to authenticated;
revoke execute on function public.create_order_atomic(uuid,uuid,timestamptz,text,jsonb) from anon,public;

create or replace function public.role_can_write()
returns boolean language sql stable security invoker set search_path=public as $$
 select coalesce(public.current_user_role() in ('OWNER','ADMIN','SALES_PERSON'::public.app_role),false);
$$;
grant execute on function public.role_can_write() to authenticated;
revoke execute on function public.role_can_write() from anon,public;

-- Role-aware RLS for operational data.
drop policy if exists "org crud" on public.orders;
create policy orders_read on public.orders for select to authenticated using(organization_id=public.current_user_org_id());
create policy orders_write on public.orders for insert to authenticated with check(organization_id=public.current_user_org_id() and public.can_manage('orders'));
create policy orders_update on public.orders for update to authenticated using(organization_id=public.current_user_org_id() and public.can_manage('orders')) with check(organization_id=public.current_user_org_id() and public.can_manage('orders'));
create policy orders_delete on public.orders for delete to authenticated using(organization_id=public.current_user_org_id() and public.can_manage('orders'));

drop policy if exists "org crud" on public.order_items;
create policy order_items_read on public.order_items for select to authenticated using(organization_id=public.current_user_org_id());
create policy order_items_write on public.order_items for all to authenticated using(organization_id=public.current_user_org_id() and public.can_manage('orders')) with check(organization_id=public.current_user_org_id() and public.can_manage('orders'));

drop policy if exists "org crud" on public.schools;
create policy schools_read on public.schools for select to authenticated using(organization_id=public.current_user_org_id());
create policy schools_write on public.schools for all to authenticated using(organization_id=public.current_user_org_id() and public.can_manage('schools')) with check(organization_id=public.current_user_org_id() and public.can_manage('schools'));

drop policy if exists "org crud" on public.school_contacts;
create policy contacts_read on public.school_contacts for select to authenticated using(organization_id=public.current_user_org_id());
create policy contacts_write on public.school_contacts for all to authenticated using(organization_id=public.current_user_org_id() and public.can_manage('schools')) with check(organization_id=public.current_user_org_id() and public.can_manage('schools'));

drop policy if exists "org crud" on public.school_visits;
create policy visits_read on public.school_visits for select to authenticated using(organization_id=public.current_user_org_id());
create policy visits_write on public.school_visits for all to authenticated using(organization_id=public.current_user_org_id() and public.can_manage('visits')) with check(organization_id=public.current_user_org_id() and public.can_manage('visits'));

drop policy if exists "org crud" on public.products;
create policy products_read on public.products for select to authenticated using(organization_id=public.current_user_org_id());
create policy products_write on public.products for all to authenticated using(organization_id=public.current_user_org_id() and public.can_manage('inventory')) with check(organization_id=public.current_user_org_id() and public.can_manage('inventory'));

drop policy if exists "org crud" on public.purchases;
create policy purchases_read on public.purchases for select to authenticated using(organization_id=public.current_user_org_id());
create policy purchases_write on public.purchases for all to authenticated using(organization_id=public.current_user_org_id() and public.can_manage('inventory')) with check(organization_id=public.current_user_org_id() and public.can_manage('inventory'));

drop policy if exists "org crud" on public.purchase_items;
create policy purchase_items_read on public.purchase_items for select to authenticated using(organization_id=public.current_user_org_id());
create policy purchase_items_write on public.purchase_items for all to authenticated using(organization_id=public.current_user_org_id() and public.can_manage('inventory')) with check(organization_id=public.current_user_org_id() and public.can_manage('inventory'));

drop policy if exists "org crud" on public.deliveries;
create policy deliveries_read on public.deliveries for select to authenticated using(organization_id=public.current_user_org_id());
create policy deliveries_write on public.deliveries for all to authenticated using(organization_id=public.current_user_org_id() and public.can_manage('deliveries')) with check(organization_id=public.current_user_org_id() and public.can_manage('deliveries'));

drop policy if exists "org crud" on public.inventory;
create policy inventory_read on public.inventory for select to authenticated using(organization_id=public.current_user_org_id());
create policy inventory_write on public.inventory for all to authenticated using(organization_id=public.current_user_org_id() and public.can_manage('inventory')) with check(organization_id=public.current_user_org_id() and public.can_manage('inventory'));

drop policy if exists "org crud" on public.inventory_transactions;
create policy inventory_tx_read on public.inventory_transactions for select to authenticated using(organization_id=public.current_user_org_id());
create policy inventory_tx_write on public.inventory_transactions for all to authenticated using(organization_id=public.current_user_org_id() and public.can_manage('inventory')) with check(organization_id=public.current_user_org_id() and public.can_manage('inventory'));

drop policy if exists "org crud" on public.payments;
create policy payments_read on public.payments for select to authenticated using(organization_id=public.current_user_org_id());
create policy payments_write on public.payments for all to authenticated using(organization_id=public.current_user_org_id() and public.can_manage('payments')) with check(organization_id=public.current_user_org_id() and public.can_manage('payments'));
