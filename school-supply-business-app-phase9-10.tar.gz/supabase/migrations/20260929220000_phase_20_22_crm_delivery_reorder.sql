-- Phase 20–22: CRM contact actions, delivery scheduling helpers and reorder automation.
-- Runtime schema changes were verified against the linked Supabase project.

create or replace function public.create_school_followup(p_school_id uuid,p_followup_at timestamptz,p_channel text,p_subject text,p_notes text,p_assigned_to uuid) returns uuid language plpgsql security invoker set search_path=public as $$
declare v_org uuid:=public.current_user_org_id(); v_id uuid;
begin
 if not exists(select 1 from public.schools where id=p_school_id and organization_id=v_org) then raise exception 'School not found'; end if;
 if p_assigned_to is not null and not exists(select 1 from public.profiles where id=p_assigned_to and organization_id=v_org) then raise exception 'Invalid team member'; end if;
 insert into public.school_followups(organization_id,school_id,followup_at,channel,subject,notes,assigned_to,created_by)
 values(v_org,p_school_id,p_followup_at,coalesce(nullif(p_channel,''),'CALL'),p_subject,p_notes,p_assigned_to,auth.uid()) returning id into v_id;
 update public.schools set next_follow_up_at=p_followup_at,updated_at=now(),updated_by=auth.uid() where id=p_school_id;
 return v_id;
end; $$;
grant execute on function public.create_school_followup(uuid,timestamptz,text,text,text,uuid) to authenticated;
revoke execute on function public.create_school_followup(uuid,timestamptz,text,text,text,uuid) from anon,public;

create or replace function public.complete_school_followup(p_followup_id uuid) returns boolean language plpgsql security invoker set search_path=public as $$
begin
 update public.school_followups set status='COMPLETED',completed_at=now(),updated_at=now() where id=p_followup_id and organization_id=public.current_user_org_id();
 return found;
end; $$;
grant execute on function public.complete_school_followup(uuid) to authenticated;
revoke execute on function public.complete_school_followup(uuid) from anon,public;

create or replace function public.reorder_suggestions() returns table(product_id uuid,product_name text,unit text,available_stock numeric,minimum_stock numeric,suggested_quantity numeric) language sql stable security invoker set search_path=public as $$
 select i.product_id,p.name,p.unit,(i.current_stock-i.reserved_stock),p.minimum_stock,greatest(p.minimum_stock*2-(i.current_stock-i.reserved_stock),p.minimum_stock)
 from public.inventory i join public.products p on p.id=i.product_id
 where i.organization_id=public.current_user_org_id() and p.active=true and (i.current_stock-i.reserved_stock)<=p.minimum_stock order by p.name;
$$;
grant execute on function public.reorder_suggestions() to authenticated;
revoke execute on function public.reorder_suggestions() from anon,public;
