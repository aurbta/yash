create index if not exists suppliers_org_idx on public.suppliers(organization_id, name);
create index if not exists deliveries_org_status_idx on public.deliveries(organization_id, status, scheduled_at);
create index if not exists purchases_org_status_idx on public.purchases(organization_id, status, purchase_date desc);
create index if not exists purchase_items_purchase_idx on public.purchase_items(purchase_id);
create index if not exists inventory_org_product_idx on public.inventory(organization_id, product_id);
create index if not exists inventory_tx_org_date_idx on public.inventory_transactions(organization_id, created_at desc);

create or replace function public.ensure_inventory_row() returns trigger language plpgsql security definer set search_path = public as $$ begin insert into public.inventory(organization_id, product_id, current_stock) values (new.organization_id, new.id, new.current_stock) on conflict (product_id) do nothing; return new; end; $$;
drop trigger if exists products_inventory_init on public.products;
create trigger products_inventory_init after insert on public.products for each row execute function public.ensure_inventory_row();
insert into public.inventory(organization_id, product_id, current_stock) select p.organization_id,p.id,p.current_stock from public.products p on conflict (product_id) do nothing;

create or replace function public.apply_inventory_transaction() returns trigger language plpgsql security definer set search_path = public as $$ declare delta numeric(14,3); begin if new.type in ('PURCHASE','RETURN') then delta:=new.quantity; elsif new.type in ('DELIVERY','ADJUSTMENT') then delta:=-new.quantity; else delta:=0; end if; insert into public.inventory(organization_id,product_id,current_stock) values(new.organization_id,new.product_id,delta) on conflict(product_id) do update set current_stock=public.inventory.current_stock+excluded.current_stock,updated_at=now(); update public.products set current_stock=(select i.current_stock from public.inventory i where i.product_id=new.product_id),updated_at=now() where id=new.product_id and organization_id=new.organization_id; return new; end; $$;
drop trigger if exists inventory_transaction_apply on public.inventory_transactions;
create trigger inventory_transaction_apply after insert on public.inventory_transactions for each row execute function public.apply_inventory_transaction();

create or replace function public.receive_purchase(p_purchase_id uuid) returns void language plpgsql security definer set search_path = public as $$ declare r record; org uuid; begin select organization_id into org from public.purchases where id=p_purchase_id; if org is null or org<>public.current_user_org_id() then raise exception 'Purchase not found or access denied'; end if; if exists(select 1 from public.inventory_transactions where reference_type='PURCHASE' and reference_id=p_purchase_id) then raise exception 'Purchase already received'; end if; for r in select product_id,quantity from public.purchase_items where purchase_id=p_purchase_id loop insert into public.inventory_transactions(organization_id,product_id,type,quantity,reference_type,reference_id,created_by,notes) values(org,r.product_id,'PURCHASE',r.quantity,'PURCHASE',p_purchase_id,auth.uid(),'Purchase received'); end loop; update public.purchases set status='RECEIVED',updated_at=now() where id=p_purchase_id; end; $$;
revoke all on function public.receive_purchase(uuid) from public; grant execute on function public.receive_purchase(uuid) to authenticated;

create or replace function public.complete_delivery(p_delivery_id uuid) returns void language plpgsql security definer set search_path = public as $$ declare d record; org uuid; item record; begin select * into d from public.deliveries where id=p_delivery_id; org:=d.organization_id; if d.id is null or org<>public.current_user_org_id() then raise exception 'Delivery not found or access denied'; end if; if d.status='DELIVERED' then raise exception 'Delivery already completed'; end if; for item in select oi.product_id,oi.quantity from public.order_items oi where oi.order_id=d.order_id and oi.product_id is not null loop insert into public.inventory_transactions(organization_id,product_id,type,quantity,reference_type,reference_id,created_by,notes) values(org,item.product_id,'DELIVERY',item.quantity,'DELIVERY',d.id,auth.uid(),'Order delivered'); end loop; update public.deliveries set status='DELIVERED',delivered_at=now(),updated_at=now() where id=d.id; update public.orders set status='DELIVERED',updated_at=now(),updated_by=auth.uid() where id=d.order_id; end; $$;
revoke all on function public.complete_delivery(uuid) from public; grant execute on function public.complete_delivery(uuid) to authenticated;

-- Security hardening: lock down trigger helpers and use invoker privileges for user-callable RPCs.
alter function public.current_user_org_id() set search_path = public;
alter function public.set_updated_at() set search_path = public;
revoke all on function public.apply_inventory_transaction() from public, anon, authenticated;
revoke all on function public.ensure_inventory_row() from public, anon, authenticated;
revoke all on function public.handle_new_user() from public, anon, authenticated;
grant execute on function public.handle_new_user() to supabase_auth_admin;
alter function public.receive_purchase(uuid) security invoker;
alter function public.complete_delivery(uuid) security invoker;
revoke all on function public.receive_purchase(uuid) from public, anon;
grant execute on function public.receive_purchase(uuid) to authenticated;
revoke all on function public.complete_delivery(uuid) from public, anon;
grant execute on function public.complete_delivery(uuid) to authenticated;
