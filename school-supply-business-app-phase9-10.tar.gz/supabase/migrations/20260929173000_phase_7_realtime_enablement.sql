-- Phase 7: enable Supabase Realtime for operational tables
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['schools','school_visits','orders','deliveries','payments','products','inventory','tasks','reminders','notifications'] LOOP
    EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
  END LOOP;
END $$;
