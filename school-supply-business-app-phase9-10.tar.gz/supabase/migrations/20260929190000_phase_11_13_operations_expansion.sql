-- Phase 11-13: reusable templates, order lifecycle controls, notification read state.
create or replace function public.update_order_status(p_order_id uuid,p_status public.order_status)
returns boolean language plpgsql security invoker set search_path=public as $$
declare v_org uuid:=public.current_user_org_id(); v_old public.order_status;
begin
 if v_org is null then raise exception 'No organization found'; end if;
 select status into v_old from public.orders where id=p_order_id and organization_id=v_org for update;
 if v_old is null then raise exception 'Order not found'; end if;
 if p_status='DELIVERED' and not exists(select 1 from public.deliveries where order_id=p_order_id and organization_id=v_org and status='DELIVERED') then raise exception 'Complete the delivery before marking the order delivered'; end if;
 update public.orders set status=p_status,updated_at=now(),updated_by=auth.uid() where id=p_order_id and organization_id=v_org;
 return true;
end; $$;
grant execute on function public.update_order_status(uuid,public.order_status) to authenticated;
revoke execute on function public.update_order_status(uuid,public.order_status) from anon,public;

create or replace function public.create_order_delivery(p_order_id uuid,p_scheduled_at timestamptz,p_responsible_user_id uuid,p_notes text)
returns uuid language plpgsql security invoker set search_path=public as $$
declare v_org uuid:=public.current_user_org_id(); v_school uuid; v_id uuid;
begin
 if v_org is null then raise exception 'No organization found'; end if;
 select school_id into v_school from public.orders where id=p_order_id and organization_id=v_org;
 if v_school is null then raise exception 'Order not found'; end if;
 if p_responsible_user_id is not null and not exists(select 1 from public.profiles where id=p_responsible_user_id and organization_id=v_org) then raise exception 'Invalid delivery user'; end if;
 select id into v_id from public.deliveries where order_id=p_order_id and organization_id=v_org;
 if v_id is not null then update public.deliveries set scheduled_at=p_scheduled_at,responsible_user_id=p_responsible_user_id,notes=p_notes,updated_at=now() where id=v_id;
 else insert into public.deliveries(organization_id,order_id,school_id,responsible_user_id,scheduled_at,status,notes,created_by) values(v_org,p_order_id,v_school,p_responsible_user_id,p_scheduled_at,'SCHEDULED',p_notes,auth.uid()) returning id into v_id; end if;
 update public.orders set status=case when status='NEW' then 'CONFIRMED' else status end,updated_at=now(),updated_by=auth.uid() where id=p_order_id;
 return v_id;
end; $$;
grant execute on function public.create_order_delivery(uuid,timestamptz,uuid,text) to authenticated;
revoke execute on function public.create_order_delivery(uuid,timestamptz,uuid,text) from anon,public;

create or replace function public.mark_notification_read(p_notification_id uuid)
returns boolean language plpgsql security invoker set search_path=public as $$ begin update public.notifications set read_at=coalesce(read_at,now()) where id=p_notification_id and user_id=auth.uid(); return found; end; $$;
grant execute on function public.mark_notification_read(uuid) to authenticated;
revoke execute on function public.mark_notification_read(uuid) from anon,public;
