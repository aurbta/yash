-- Phase 23-25: partial delivery, supplier payments, operational dashboard

create or replace function public.complete_delivery_partial(p_delivery_id uuid, p_delivered jsonb, p_notes text default null)
returns void language plpgsql security definer set search_path=public as $$
declare
  d record; r record; qty numeric; delivered_total numeric; ordered_total numeric;
  org uuid := public.current_user_org_id();
begin
  if org is null then raise exception 'Organization not found'; end if;
  select * into d from public.deliveries where id=p_delivery_id and organization_id=org for update;
  if d.id is null then raise exception 'Delivery not found or access denied'; end if;
  if d.status='DELIVERED' then raise exception 'Delivery already completed'; end if;
  if d.status not in ('PREPARING','OUT_FOR_DELIVERY','RESCHEDULED') then raise exception 'Delivery is not ready to complete'; end if;

  for r in select di.id, di.order_item_id, di.ordered_quantity, oi.product_id
           from public.delivery_items di join public.order_items oi on oi.id=di.order_item_id
           where di.delivery_id=p_delivery_id
  loop
    qty := greatest(0, coalesce((p_delivered ->> r.id::text)::numeric, 0));
    if qty > r.ordered_quantity then raise exception 'Delivered quantity cannot exceed ordered quantity'; end if;
    update public.delivery_items set delivered_quantity=qty, updated_at=now() where id=r.id;
    if r.product_id is not null and qty > 0 then
      if exists(select 1 from public.inventory_transactions where organization_id=org and reference_type='DELIVERY_ITEM' and reference_id=r.id) then
        raise exception 'Delivery item inventory has already been posted';
      end if;
      insert into public.inventory_transactions(organization_id,product_id,type,quantity,reference_type,reference_id,created_by,notes)
      values(org,r.product_id,'DELIVERY',qty,'DELIVERY_ITEM',r.id,auth.uid(),'Partial delivery');
    end if;
  end loop;

  select coalesce(sum(delivered_quantity),0), coalesce(sum(ordered_quantity),0) into delivered_total, ordered_total
  from public.delivery_items where delivery_id=p_delivery_id;
  if delivered_total <= 0 then raise exception 'At least one item must be delivered'; end if;
  update public.deliveries set status=case when delivered_total>=ordered_total then 'DELIVERED' else 'RESCHEDULED' end,
    delivered_at=case when delivered_total>=ordered_total then now() else null end,
    notes=coalesce(p_notes,notes), updated_at=now() where id=p_delivery_id;
  update public.orders set status=case when delivered_total>=ordered_total then 'DELIVERED' else 'PARTIALLY_DELIVERED' end,
    updated_at=now(), updated_by=auth.uid() where id=d.order_id;
end; $$;
revoke all on function public.complete_delivery_partial(uuid,jsonb,text) from public, anon;
grant execute on function public.complete_delivery_partial(uuid,jsonb,text) to authenticated;

create or replace function public.create_supplier_payment(p_supplier_id uuid, p_purchase_id uuid, p_amount numeric, p_payment_mode text, p_reference_number text default null, p_notes text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare org uuid:=public.current_user_org_id(); pid uuid;
  purchase_total numeric; purchase_paid numeric; supplier uuid;
begin
  if org is null then raise exception 'Organization not found'; end if;
  if p_amount is null or p_amount<=0 then raise exception 'Payment amount must be greater than zero'; end if;
  select id,supplier_id,total_amount,paid_amount into pid,supplier,purchase_total,purchase_paid from public.purchases where id=p_purchase_id and organization_id=org for update;
  if pid is null then raise exception 'Purchase not found'; end if;
  if supplier<>p_supplier_id then raise exception 'Supplier does not match purchase'; end if;
  if p_amount > greatest(purchase_total-purchase_paid,0) then raise exception 'Payment exceeds purchase outstanding'; end if;
  insert into public.supplier_payments(organization_id,supplier_id,purchase_id,amount,payment_mode,reference_number,notes,created_by)
  values(org,p_supplier_id,p_purchase_id,p_amount,upper(trim(coalesce(p_payment_mode,'CASH'))),nullif(trim(p_reference_number),''),p_notes,auth.uid()) returning id into pid;
  update public.purchases set paid_amount=coalesce(paid_amount,0)+p_amount, updated_at=now() where id=p_purchase_id;
  update public.suppliers set outstanding_amount=greatest(coalesce(outstanding_amount,0)-p_amount,0), updated_at=now() where id=p_supplier_id and organization_id=org;
  return pid;
end; $$;
revoke all on function public.create_supplier_payment(uuid,uuid,numeric,text,text,text) from public, anon;
grant execute on function public.create_supplier_payment(uuid,uuid,numeric,text,text,text) to authenticated;

create or replace function public.dashboard_summary()
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_org uuid:=public.current_user_org_id(); v_today date:=current_date; result jsonb;
begin
 if v_org is null then raise exception 'No organization found'; end if;
 select jsonb_build_object(
  'schools_total',(select count(*) from schools where organization_id=v_org),
  'schools_active',(select count(*) from schools where organization_id=v_org and status='ACTIVE'),
  'visits_today',(select count(*) from school_visits where organization_id=v_org and started_at::date=v_today),
  'orders_today',(select count(*) from orders where organization_id=v_org and order_date::date=v_today),
  'orders_pending',(select count(*) from orders where organization_id=v_org and status in ('NEW','CONFIRMED','PREPARING','READY','OUT_FOR_DELIVERY','PARTIALLY_DELIVERED')),
  'deliveries_today',(select count(*) from deliveries where organization_id=v_org and scheduled_at::date=v_today and status<>'DELIVERED'),
  'outstanding',coalesce((select sum(greatest(total_amount-paid_amount,0)) from orders where organization_id=v_org and total_amount>paid_amount),0),
  'overdue_orders',(select count(*) from orders where organization_id=v_org and total_amount>paid_amount and expected_delivery_at is not null and expected_delivery_at<now() and status not in ('DELIVERED','CANCELLED')),
  'low_stock',(select count(*) from products where organization_id=v_org and active and current_stock<=minimum_stock),
  'sales_30d',coalesce((select sum(total_amount) from orders where organization_id=v_org and order_date>=now()-interval '30 days'),0),
  'collections_30d',coalesce((select sum(amount) from payments where organization_id=v_org and paid_at>=now()-interval '30 days'),0),
  'followups_today',(select count(*) from reminders where organization_id=v_org and completed_at is null and due_at::date<=v_today),
  'tasks_today',(select count(*) from tasks where organization_id=v_org and completed_at is null and due_at::date<=v_today),
  'supplier_outstanding',coalesce((select sum(greatest(total_amount-paid_amount,0)) from purchases where organization_id=v_org),0)
 ) into result; return result;
end; $$;
revoke all on function public.dashboard_summary() from public,anon; grant execute on function public.dashboard_summary() to authenticated;

create index if not exists deliveries_org_status_idx on public.deliveries(organization_id,status,scheduled_at desc);
create index if not exists supplier_payments_org_purchase_idx on public.supplier_payments(organization_id,purchase_id,paid_at desc);
create index if not exists delivery_items_delivery_idx on public.delivery_items(organization_id,delivery_id);
