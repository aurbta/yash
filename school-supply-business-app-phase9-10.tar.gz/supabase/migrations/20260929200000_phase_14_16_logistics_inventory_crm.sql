-- Phase 14-16: delivery preparation, purchasing indexes, school follow-up CRM.
create table if not exists public.delivery_items (
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null references public.organizations(id) on delete cascade,
 delivery_id uuid not null references public.deliveries(id) on delete cascade,
 order_item_id uuid not null references public.order_items(id) on delete cascade,
 ordered_quantity numeric(14,3) not null check(ordered_quantity>0),
 delivered_quantity numeric(14,3) not null default 0 check(delivered_quantity>=0 and delivered_quantity<=ordered_quantity),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 unique(delivery_id,order_item_id)
);
alter table public.delivery_items enable row level security;
drop policy if exists delivery_items_org on public.delivery_items;
create policy delivery_items_org on public.delivery_items for all to authenticated using(organization_id=public.current_user_org_id()) with check(organization_id=public.current_user_org_id());
create index if not exists delivery_items_delivery_idx on public.delivery_items(delivery_id);

create table if not exists public.school_followups (
 id uuid primary key default gen_random_uuid(), organization_id uuid not null references public.organizations(id) on delete cascade,
 school_id uuid not null references public.schools(id) on delete cascade, followup_at timestamptz not null,
 channel text not null default 'CALL', status text not null default 'PENDING', subject text, notes text,
 completed_at timestamptz, assigned_to uuid references public.profiles(id) on delete set null,
 created_by uuid references public.profiles(id) on delete set null, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
alter table public.school_followups enable row level security;
drop policy if exists school_followups_org on public.school_followups;
create policy school_followups_org on public.school_followups for all to authenticated using(organization_id=public.current_user_org_id()) with check(organization_id=public.current_user_org_id());
create index if not exists school_followups_org_due_idx on public.school_followups(organization_id,status,followup_at);
create index if not exists school_followups_school_idx on public.school_followups(school_id,followup_at desc);

create index if not exists purchases_supplier_date_idx on public.purchases(organization_id,supplier_id,purchase_date desc);
create index if not exists purchase_items_product_idx on public.purchase_items(product_id);
create index if not exists inventory_low_stock_idx on public.inventory(organization_id,current_stock);

create or replace function public.prepare_delivery(p_delivery_id uuid)
returns boolean language plpgsql security invoker set search_path=public as $$
declare v_org uuid:=public.current_user_org_id(); v_order uuid; r record;
begin
 select order_id into v_order from public.deliveries where id=p_delivery_id and organization_id=v_org;
 if v_order is null then raise exception 'Delivery not found'; end if;
 for r in select id,quantity from public.order_items where order_id=v_order and product_id is not null loop
  insert into public.delivery_items(organization_id,delivery_id,order_item_id,ordered_quantity) values(v_org,p_delivery_id,r.id,r.quantity) on conflict(delivery_id,order_item_id) do nothing;
 end loop;
 update public.deliveries set status='PREPARING',updated_at=now() where id=p_delivery_id and organization_id=v_org;
 update public.orders set status='PREPARING',updated_at=now(),updated_by=auth.uid() where id=v_order and organization_id=v_org;
 return true;
end; $$;
grant execute on function public.prepare_delivery(uuid) to authenticated;
revoke execute on function public.prepare_delivery(uuid) from anon,public;
