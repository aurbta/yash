-- Phase 8 security hardening
revoke execute on function public.dashboard_summary() from public, anon;
revoke execute on function public.recent_activity(integer) from public, anon;
revoke execute on function public.report_summary(timestamptz,timestamptz) from public, anon;
revoke execute on function public.sales_report(timestamptz,timestamptz) from public, anon;
revoke execute on function public.log_activity() from public, anon;
revoke execute on function public.set_updated_at() from public, anon, authenticated;
revoke execute on function public.current_user_org_id() from public, anon;
grant execute on function public.dashboard_summary() to authenticated;
grant execute on function public.recent_activity(integer) to authenticated;
grant execute on function public.report_summary(timestamptz,timestamptz) to authenticated;
grant execute on function public.sales_report(timestamptz,timestamptz) to authenticated;

-- Recreate payment RPC with explicit organization/school/order consistency checks.
drop function if exists public.create_payment(uuid,uuid,numeric,text,text,text);
create function public.create_payment(
  p_school_id uuid,
  p_order_id uuid,
  p_amount numeric,
  payment_mode text,
  p_reference_number text,
  p_notes text
)
returns uuid
language plpgsql
security invoker
set search_path=public
as $$
declare
  v_org uuid := public.current_user_org_id();
  v_id uuid;
  v_order_school uuid;
begin
  if v_org is null then raise exception 'No organization found'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Payment amount must be greater than zero'; end if;
  if p_school_id is null then raise exception 'School is required'; end if;
  if not exists(select 1 from public.schools where id=p_school_id and organization_id=v_org) then raise exception 'Invalid school'; end if;
  if p_order_id is not null then
    select school_id into v_order_school from public.orders where id=p_order_id and organization_id=v_org;
    if v_order_school is null then raise exception 'Invalid order'; end if;
    if v_order_school <> p_school_id then raise exception 'Payment school does not match order school'; end if;
  end if;
  insert into public.payments(organization_id,school_id,order_id,amount,payment_mode,reference_number,notes,created_by)
  values(v_org,p_school_id,p_order_id,p_amount,payment_mode,p_reference_number,p_notes,auth.uid())
  returning id into v_id;
  return v_id;
end;
$$;
grant execute on function public.create_payment(uuid,uuid,numeric,text,text,text) to authenticated;
revoke execute on function public.create_payment(uuid,uuid,numeric,text,text,text) from public, anon;
