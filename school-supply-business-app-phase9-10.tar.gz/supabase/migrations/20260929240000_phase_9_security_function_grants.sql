-- Phase 9 security hardening: keep SECURITY DEFINER RPCs inaccessible to
-- anonymous/public callers while preserving authenticated application access.
revoke execute on function public.complete_delivery_partial(uuid, jsonb, text) from public, anon;
grant execute on function public.complete_delivery_partial(uuid, jsonb, text) to authenticated;

revoke execute on function public.create_supplier_payment(uuid, uuid, numeric, text, text, text) from public, anon;
grant execute on function public.create_supplier_payment(uuid, uuid, numeric, text, text, text) to authenticated;

revoke execute on function public.dashboard_summary() from public, anon;
grant execute on function public.dashboard_summary() to authenticated;
