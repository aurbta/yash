import Link from 'next/link';
export function ReorderLink({productId}:{productId:string}){return <Link href={`/dashboard/purchases/new?product=${productId}`} className="rounded-lg border px-3 py-1.5 text-xs font-semibold">Create purchase</Link>}
