'use client';
import { useEffect, useState } from 'react';
import { WifiOff, Download } from 'lucide-react';

export function PwaRuntime(){
  const [online,setOnline]=useState(true);
  const [installPrompt,setInstallPrompt]=useState<any>(null);
  useEffect(()=>{
    setOnline(navigator.onLine);
    const onOnline=()=>setOnline(true), onOffline=()=>setOnline(false), onBeforeInstall=(e:any)=>{e.preventDefault();setInstallPrompt(e)};
    window.addEventListener('online',onOnline); window.addEventListener('offline',onOffline); window.addEventListener('beforeinstallprompt',onBeforeInstall as EventListener);
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(()=>{});
    return()=>{window.removeEventListener('online',onOnline);window.removeEventListener('offline',onOffline);window.removeEventListener('beforeinstallprompt',onBeforeInstall as EventListener)};
  },[]);
  if(online && !installPrompt) return null;
  const install=async()=>{if(!installPrompt)return;await installPrompt.prompt();setInstallPrompt(null)};
  return <div className="fixed bottom-20 left-3 right-3 z-50 space-y-2 lg:bottom-4 lg:left-auto lg:right-4 lg:w-auto">
    {!online && <div className="flex items-center gap-2 rounded-xl border bg-white px-4 py-3 text-sm shadow-lg"><WifiOff size={17} className="text-amber-600"/><span>Offline mode — cached screens remain available; new changes need a connection.</span></div>}
    {online && installPrompt && <button onClick={install} className="inline-flex items-center gap-2 rounded-xl bg-green-700 px-4 py-3 text-sm font-semibold text-white shadow-lg"><Download size={17}/>Install School Supply OS</button>}
  </div>;
}
