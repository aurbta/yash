'use client';
import { MessageCircle, Phone } from 'lucide-react';
export function ContactActions({phone,whatsapp}:{phone?:string|null;whatsapp?:string|null}){
 const clean=(v:string)=>v.replace(/[^0-9+]/g,''); const w=whatsapp||phone; return <div className="flex gap-2 mt-2">{phone&&<a href={`tel:${clean(phone)}`} className="inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-semibold"><Phone size={13}/>Call</a>}{w&&<a target="_blank" rel="noreferrer" href={`https://wa.me/${clean(w).replace(/^\+/,'')}`} className="inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-semibold text-green-700"><MessageCircle size={13}/>WhatsApp</a>}</div>
}
