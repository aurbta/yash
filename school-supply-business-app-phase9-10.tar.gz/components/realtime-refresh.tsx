'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

const TABLES=['schools','school_visits','orders','deliveries','payments','products','inventory','tasks','reminders','notifications'];
export function RealtimeRefresh(){
  const router=useRouter();
  useEffect(()=>{
    const supabase=createClient();
    const channel=supabase.channel('workspace-live');
    TABLES.forEach(table=>channel.on('postgres_changes',{event:'*',schema:'public',table},()=>router.refresh()));
    channel.subscribe();
    return()=>{supabase.removeChannel(channel)};
  },[router]);
  return null;
}
